# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'



library(glmnet) ;
set.seed(2019);

myglmnet = function(z, y, a=0.5) { #ridge(a=0) lasso (a=1) enet(a=any);
  # Center and scale variables
  z = as.matrix(t((t(z)-apply(z,2,mean))/apply(z,2,sd))) # Find lambda by CV plot(u<-cv.glmnet(x,y,alpha=a))
  # Plot full solution path
  plot(glmnet(z,y,alpha=a ));
  plot(u<-cv.glmnet(x,y,alpha=a))
  lam=c(u$lambda.1se,u$lambda.min)
  v <- glmnet(z,y,alpha=a,lambda=lam)
  # Plot Lambda path
  plot(v)
  # Output lambda and estimates
  lst<-list(lambda=lam,beta=v$beta)
}

hello <- function() {
  print("Hello, world!")
}
